
public class FactoryConnection {
    
}
